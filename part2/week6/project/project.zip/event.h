#pragma once

#include <iostream>
#include <string>

std::string ParseEvent(std::istream& is);
