#pragma once

void TestAll();
