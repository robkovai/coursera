#pragma once

void TestDatabase();
